//
//  ContactUsView.swift
//  TaskManager
//
//  Created by user266853 on 9/5/24.
//

import SwiftUI

struct ContactUsView: View {
    @State private var firstName: String = ""
    @State private var lastName: String = ""
    @State private var email: String = ""
    @State private var phone: String = ""
    @State private var message: String = ""
    @State private var showAlert: Bool = false // State for alert

    var body: some View {
        Form {
            Section(header: Text("Contact Information")
                .foregroundColor(.black)
            ) {
                TextField("First Name", text: $firstName)
                TextField("Last Name", text: $lastName)
                TextField("Email", text: $email)
                    .keyboardType(.emailAddress)
                TextField("Phone", text: $phone)
                    .keyboardType(.phonePad)
            }

            Section(header: Text("Message")
                .foregroundColor(.black)            ) {
                TextEditor(text: $message)
                    .frame(height: 150) // Set the height of the message box
            }

            Section {
                Button(action: {
                    // Handle form submission, e.g., send email
                    submitForm()
                }) {
                    Text("Submit")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                }
            }
        }
        .navigationTitle("Contact Us")
               .alert(isPresented: $showAlert) { // Show the alert after submission
                   Alert(title: Text("Success"), message: Text("Message sent successfully!"), dismissButton: .default(Text("OK")))
               }
           }

    // Simulated form submission
    func submitForm() {
        // You can handle the form data here (e.g., validation, sending an email, etc.)
        print("Form submitted")
        print("First Name: \(firstName)")
        print("Last Name: \(lastName)")
        print("Email: \(email)")
        print("Phone: \(phone)")
        print("Message: \(message)")
        
        // Show the success alert
                showAlert = true    }
}



#Preview {
    ContactUsView()
}
