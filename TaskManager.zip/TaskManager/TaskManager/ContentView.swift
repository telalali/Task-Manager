//
//  ContentView.swift
//  TaskManager
//
//  Created by user266853 on 9/3/24.
//
import SwiftUI

struct ContentView: View {
    @State private var taskToEdit: Task?
    @State private var isEditing: Bool = false
    @StateObject private var taskViewModel = TaskViewModel()
    @State private var newTaskTitle: String = ""
    @State private var showContactUsPage = false
    var body: some View {
            NavigationView {
                VStack {
                    // Navigation to Contact Us page
                    NavigationLink(destination: ContactUsView(), isActive: $showContactUsPage) {
                        EmptyView()
                    }

                    // Button to send email (navigates to Contact Us)
                    Button("Send Email") {
                        showContactUsPage.toggle()
                    }

                HStack {
                                    Button(action: {
                                        if let url = URL(string: "tel://1234567890"), UIApplication.shared.canOpenURL(url) {
                                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                                        }
                                    }) {
                                        Image(systemName: "phone.fill")
                                            .foregroundColor(.blue)
                                            .padding(.leading) // Moves the icon to the left
                                    }
                                    Spacer() // Pushes the content to the left
                                }
                                .padding()
                Image("Image")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .padding(.top)


                List {
                    ForEach(taskViewModel.tasks) { task in
                        HStack {
                            Text(task.title)
                                .strikethrough(task.isCompleted, color: .black)
                                .foregroundColor(task.isCompleted ? .gray : .black)
                            Spacer()
                            Button(action: {
                                taskViewModel.toggleTaskCompletion(task: task)
                            }) {
                                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                            }
                        }
                    }
                    .onDelete(perform: taskViewModel.removeTask)
                }

                HStack {
                    TextField("New Task", text: $newTaskTitle)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button(action: {
                        taskViewModel.addTask(title: newTaskTitle)
                        newTaskTitle = ""
                    }) {
                        Image(systemName: "plus")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                    }
                    .disabled(newTaskTitle.isEmpty)
                }
                .padding()
            }
            .navigationTitle("Task Manager")
            .toolbar {
                EditButton()
            }
        }
    }
}

#Preview {
    ContentView()
}
