//
//  TaskManagerApp.swift
//  TaskManager
//
//  Created by user266853 on 9/3/24.
//

import SwiftUI

@main
struct TaskManagementApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
